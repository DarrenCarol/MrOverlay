Clean Personal - Batocera theme
Install: copy the "clean-personal" folder to /userdata/themes/ then
MAIN MENU > UI SETTINGS > THEME SET > Clean Personal.
Set each system's gamelist view to "video" (or "detailed") in the gamelist options.

Metadata mapping used:
  md_video      -> video (shows screenshot if no video)
  md_thumbnail  -> boxart (right of the video)
  md_marquee    -> game logo
Colours/fonts: edit the <variables> block at the top of theme.xml.
System logos: drop SVGs into art/logos/ named after the system (snes.svg, psx.svg...).
Text is shown in the carousel when a logo is missing.

Background video: the selected game's video plays full screen behind the
gamelist. Video dimming is the <veil> variable in theme.xml (00-ff, 80 = 50%), card
translucency is <cardAlpha>. Videos keep their aspect ratio (4:3 clips are
pillarboxed over the gradient).
System view plays a random game video from the highlighted system ({random} path).
