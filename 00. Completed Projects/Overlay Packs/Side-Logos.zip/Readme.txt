Bezel Packs by Mr. Overlay:
https://mroverlay.org


Installation Instructions:
1. For RetroArch / Lakka / RetroPie
Place the the .cfg and .png files into RetroArch's overlay folder. Add the contents of each .txt file to the relevant cores .cfg file.
Need support? Go to https://mroverlay.org/setup

2. For Batocera
Place the .png and .info files in the "/share/decorations/systems" directory (create the "systems" folder if it doesn't exist already). You do not need any further files from the zip.

Changelog:
02/04/21 - 11 System Launch.