Dynamic Wallpaper Packs by Mr. Overlay:
https://mroverlay.org


Installation Instructions:
1. Enable the XMB driver within RetroArch. To do this go to Settings > Drivers > Menu Driver. Restart RetroArch once this is done; you'll notice the theme change.

2. Enable Dynamic Wallpapers. Head to Settings > User Interface > Appearance > Dynamic Background. In this menu also ensure that Background Opacity is set to 1.000 and Menu Shader Pipeline is Off.

3. Place all the PNG files in a folder of your choosing. Remember where this folder is (IE, Desktop). Open up RetroArch and go to Settings > Directory. Select Dyanmic Backgrounds and update this folder to the one created in Step 2.

4. Restart RertoArch and you're dynamic wallpapers should now be live!

Changelog:
- 26th March 2021: Watara Supervision Added.

- 14th March 2021: Cave Story Added.

- 18th Feb 2021: Neo Geo MVS Added.

- 14th Feb 2021: Renamed MSX to Microsoft - MSX.

- 10th Feb 2021: Renamed MS-DOS.png and NEC - PC-9800.png renamed to DOS.png and NEC - PC-98.png respectively.

-9th Feb 2021: SNK - Neo Geo AES and Phillips CD-i Added.

-6th Feb 2021: Menu renamed to Main Menu to allow automation. Preview.png removed. Netplay, Images, Music, Settings, Explore, Import Content, Nintendo Game & Watch, Nintendo Satellaview and Videos added.

- 5th Feb 2021: Nintendo 3DS, Fairchild Channel F, Nintendo Wii & SuperGrafx/TurboGrafx-16 CD added.

- 4th Feb 2021: Atari 5200 added.

- 2nd Feb 2021: Sharp X6800 added.

- 1st Feb 2021: Mattel Intellivision, NEC PC-9800 and MS-DOS added.

Included Wallpapers:
Arcade
Atari 2600
Atari 5200
Atari 7800
Atari Jaguar
Atari Lynx
Atari ST
Bandai WonderSwan
Bandai WonderSwan Color
ColecoVision
Commodore Amiga
Commodore 64
DOOM
Explore
Fairchild Channel F
Favorites
GCE Vectrex
History
Images
Import Content
Magnavox Oddysey2
Main Menu
Mattel Intellivision
Microsoft Xbox
MS-DOS
MSX
Music
NEC � PC Engine/TurboGrafx16
NEC � PC Engine/TurboGrafx16 CD
NEC � PC-FX
NEC - PC-9800
NEC � SuperGrafx
Netplay
Nintendo 3DS
Nintendo Famicom
Nintendo Famicom Disk System
Nintendo Game & Watch
Nintendo Game Boy Advance
Nintendo Game Boy
Nintendo Game Boy Color
Nintendo GameCube
Nintendo 64
Nintendo DS
Nintendo Entertainment System
Nintendo Satellaview
Nintendo Super Famicom
Nintendo Super Entertainment System
Nintendo Virtual Boy
Nintendo Wii
Phillips CD-i
Sega 32X
Sega Dreamcast
Sega Game Gear
Sega Master System
Sega Mega Drive/Genesis
Sega Mega CD/Sega CD
Sega Saturn
Sega SG-1000
Settings
Sharp - X68000
Sinclair ZX Spectrum
SNK - NeoGeo AES
SNK � NeoGeo CD
SNK � NeoGeo Pocket
SNK � NeoGeo Pocket Color
SNK - NeoGeo MVS
Sony � PlayStation
Sony � PlayStation 2
Sony � PlayStation Portable
The 3DO Company � 3DO
Videos
Watara - Supervision


