Dynamic Wallpapers by Mr. Overlay:


Installation Instructions:
1. Enable the XMB driver within RetroArch. To do this go to Settings > Drivers > Menu Driver. Restart RetroArch once this is done; you'll notice the theme change.

2. Enable Dynamic Wallpapers. Head to Settings > User Interface > Appearance > Dynamic Background. In this menu also ensure that Background Opacity is set to 1.000 and Menu Shader Pipeline is Off.

3. Place all the PNG files in a folder of your choosing. Remember where this folder is (IE, Desktop). Open up RetroArch and go to Settings > Directory. Select Dyanmic Backgrounds and update this folder to the one created in Step 2.

4. Restart RertoArch and you're dynamic wallpapers should now be live!

Changelog:
- 01/04/21 - Initial Launch