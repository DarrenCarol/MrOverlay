Bezel Packs by Mr. Overlay:

1. For RetroArch / Lakka / RetroPie
Place the the .cfg and .png files into RetroArch's overlay folder. Add the contents of each .txt file to the relevant cores .cfg file, updating the filepath accordingly. 

2. For Batocera
Place the .png and .info files in the "/share/decorations/systems" directory (create the "systems" folder if it doesn't exist already). You do not need any further files from the zip.


Installation Instructions:
1. For RetroArch / Lakka / RetroPie
Place the the .cfg and .png files into RetroArch's overlay folder. Add the contents of each .txt file to the relevant cores .cfg file, updating the filepath accordingly. You do not need any further files from the zip.

2. For Batocera
Place the .png and .info files in the "/share/decorations/systems" directory (create the "systems" folder if it doesn't exist already). You do not need any further files from the zip.

Changelog:
- 15th March 2021: Arcade Horizontal and Vertical Added.

- 14th March 2021: Nintendo DS added.

- 23rd Feb 2021: Version 1 released with 30 initial systems.

Included Systems:
- Arcade Horizontal
- Arcade Vertical
- Atari 2600
- Atari 5200
- Atari 7800
- Atari Lynx
- Atari ST
- Atari Jaguar
- Commodore 64
- Mattel Intellivision
- NEC PC Engine / TurboGrafx 16
- NEC PC-FX
- NEC Super Grafx
- Nintendo DS
- Nintendo Entertainment System
- Nintendo Gameboy
- Nintendo Gameboy Color
- Nintendo Gameboy Advance
- Nintendo N64
- Nintendo Super Nintendo Entertainment System
- Sega 32X
- Sega CD
- Sega Dreamcast
- Sega Gamegear
- Sega Genesis
- Sega Master System
- Sega Mega Drive
- Sega Saturn
- Sega SG-1000
- Sinclair ZX Spectrum
- Sony PlayStation
- The 3DO Company